package server;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.RemoteRef;
import java.rmi.server.UnicastRemoteObject;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import client.chatClientInterface;

/**
 * Won Suk Cho
 * Candace Mercado
 * Anna Santos
 * Jaymee Villacruz
 *
 */
public class ChatServer extends UnicastRemoteObject implements ChatServer2 {
	String line = "---------------------------------------------\n";
	private Vector<ChatDetails> clientDetails;
	private static final long serialVersionUID = 1L;
	
	//Constructor
	public ChatServer() throws RemoteException {
		super();
		clientDetails = new Vector<ChatDetails>(10, 1);
	}

	public static void main(String[] args) {
		startRMIRegistry();
		String hostName = "localhost";
		String serviceName = "GroupChatService";
		
		if(args.length == 2){
			hostName = args[0];
			serviceName = args[1];
		}

		try{
            ChatServer2 hello = new ChatServer();
			Naming.rebind("rmi://" + hostName + "/" + serviceName, hello);
			System.out.println(" Server is running...");
		}
		catch(Exception e){
			System.out.println("Server had problems starting");
		}	
	}

	public static void startRMIRegistry() {
		String porttry;
		try{
			
			porttry = JOptionPane.showInputDialog("Type PORT number:");
			if(porttry.equals(" "))
				porttry.equals("1099");

     		java.rmi.registry.LocateRegistry.createRegistry(Integer.parseInt(porttry));
            System.out.println(" Server ready");
		}
		catch(RemoteException e) {
			e.printStackTrace();
		}
	}

	public String sayHello(String ClientName) throws RemoteException {
		System.out.println(ClientName + " sent a message");
		return "Hello " + ClientName + " from group chat server";
	}

	public void updateChat(String name, String nextPost) throws RemoteException {
		String message =  name + " : " + nextPost + "\n";
		sendToAll(message);
	}

	@Override
	public void getClient(RemoteRef ref) throws RemoteException {
		//System.out.println("\n" + ref.remoteToString() + "\n");
		try{
			System.out.println(line + ref.toString());
		}catch(Exception e){
			e.printStackTrace();
		}
	}//end passIDentity

	@Override
	public void registerListener(String[] details) throws RemoteException {	
		System.out.println(new Date(System.currentTimeMillis()));
		System.out.println(details[0] + " has joined the chat session");
		System.out.println(details[0] + "'s name : " + details[1]);
		System.out.println(details[0] + "'s service : " + details[2]);
		registerChatter(details);
	}

	private void registerChatter(String[] details){
		try{
			chatClientInterface nextClient = ( chatClientInterface )Naming.lookup("rmi://" + details[1] + "/" + details[2]);

			clientDetails.addElement(new ChatDetails(details[0], nextClient));

			nextClient.receiveServersMessage("[Server] : Hello " + details[0] + " you are now ready to chat!.\n");

			sendToAll("[Server] : " + details[0] + " has joined the group.\n");

			updateClientList();
		}
		catch(RemoteException | MalformedURLException | NotBoundException e){
			e.printStackTrace();
		}
	}

	private void updateClientList() {
		String[] currentUsers = getUserList();	
		for(ChatDetails c : clientDetails){
			try {
				c.getClient().refreshUsers(currentUsers);
			} 
			catch (RemoteException e) {
				e.printStackTrace();
			}
		}	
	}

	private String[] getUserList(){
		// generate an array of current users
		String[] allUsers = new String[clientDetails.size()];
		for(int i = 0; i< allUsers.length; i++){
			allUsers[i] = clientDetails.elementAt(i).getName();
		}
		return allUsers;
	}

	public void sendToAll(String newMessage){	
		for(ChatDetails c : clientDetails){
			try {
				c.getClient().receiveServersMessage(newMessage);
			} 
			catch (RemoteException e) {
				e.printStackTrace();
			}
		}	
	}

	@Override
	public void leaveChat(String userName) throws RemoteException{
		
		for(ChatDetails c : clientDetails){
			if(c.getName().equals(userName)){
				System.out.println(line + userName + " left the chat session");
				System.out.println(new Date(System.currentTimeMillis()));
				clientDetails.remove(c);
				break;
			}
		}		
		if(!clientDetails.isEmpty()){
			updateClientList();
		}
	}

	@Override
	public void sendPM(int[] privateGroup, String privateMessage) throws RemoteException{
        ChatDetails pc;
		for(int i : privateGroup){
			pc= clientDetails.elementAt(i);
			pc.getClient().receiveServersMessage(privateMessage);
		}
	}
	
}



