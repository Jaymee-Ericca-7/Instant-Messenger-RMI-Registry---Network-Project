package server;

import client.chatClientInterface;


public class ChatDetails {

    public String name;
    public chatClientInterface client;

    //constructor
    public ChatDetails(String name, chatClientInterface client){
        this.name = name;
        this.client = client;
    }

    //getters and setters
    public String getName(){
        return name;
    }
    public chatClientInterface getClient(){
        return client;
    }


}
