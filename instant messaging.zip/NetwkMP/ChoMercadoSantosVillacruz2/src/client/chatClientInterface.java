package client;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Won Suk Cho
 * Candace Mercado
 * Anna Santos
 * Jaymee Villacruz
 *
 */
public interface chatClientInterface extends Remote{
	
	/**
	 * This method gets a message from the chat server
	 * This is how the clients interact with each other in the network
	 * This will be used by the server in order to send strings to us
	 */
	public void receiveServersMessage(String msg) throws RemoteException;
	
	/**
	 * This method refreshes the list of users
	 * It adds the new users to the list
	 */
	public void refreshUsers(String[] usersNow) throws RemoteException;
	
}
/**
 * 
 * 
 * 
 *
 */