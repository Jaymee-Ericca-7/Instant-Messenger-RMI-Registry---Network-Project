package client;
import server.ChatServer2;

import java.net.MalformedURLException;
import java.rmi.ConnectException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import javax.swing.JOptionPane;

/**
 * 
 * Won Suk Cho
 * Candace Mercado
 * Anna Santos
 * Jaymee Villacruz
 *
 */
public class chatClient  extends UnicastRemoteObject implements chatClientInterface {

	private static final long serialVersionUID = 7468891722773409712L;
	chatClientGUI chatGUI;
	private String nHost = "localhost";
	private String nService = "GroupChatService";
	private String nClientService;
	private String name;
	protected ChatServer2 serverInterface;
	protected boolean connectionProblem = false;


	/**
	 * Constructor
	 */
	public chatClient(chatClientGUI chatClientGUI, String userName) throws RemoteException {
		super();
		this.chatGUI = chatClientGUI;
		this.name = userName;
		this.nClientService = "ClientListenService_" + userName;
	}

	public void runClient() throws RemoteException {		
		String[] clientInfo = {name, nHost, nClientService};	

		try {
			Naming.rebind("rmi://" + nHost + "/" + nClientService, this);
			serverInterface = (ChatServer2)Naming.lookup("rmi://" + nHost + "/" + nService);
		}
		catch (ConnectException  e) {
			JOptionPane.showMessageDialog(chatGUI.frame, 
					                      "Server is unavailable. Try again.", 
					                      "Error: Connection Problem ", 
					                      JOptionPane.ERROR_MESSAGE);
			connectionProblem = true;
			e.printStackTrace();
		}
		catch(NotBoundException | MalformedURLException me){
			connectionProblem = true;
			me.printStackTrace();
		}
		if(!connectionProblem){
			regServer(clientInfo);
		}	
		System.out.println("Client started running!\n");
	}

	
	public void regServer(String[] clientInfo) {

		try{
			serverInterface.getClient(this.ref);
			serverInterface.registerListener(clientInfo);			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}


	@Override
	public void refreshUsers(String[] usersNow) throws RemoteException {

		//this disables the private chat if less than 2 users
		int count = usersNow.length;
		
		if(count >= 3)
			chatGUI.privateMsgButton.setEnabled(true);
		else
			chatGUI.privateMsgButton.setEnabled(false);


		chatGUI.userPanel.remove(chatGUI.clientPanel);
		chatGUI.setClientPanel(usersNow);
		chatGUI.clientPanel.repaint();
		chatGUI.clientPanel.revalidate();
	}

	@Override
	public void receiveServersMessage(String msg) throws RemoteException {
		
		System.out.println(msg);
		chatGUI.textArea.append(msg); //append message and show latest appended text
		chatGUI.textArea.setCaretPosition(chatGUI.textArea.getDocument().getLength()); 
	}

}
